define(["./Dashboard.ext"],function(t){return{getContext:function(){return t.getCdfBase()+"/context/get";
}}});