define(["./Dashboard.ext"],function(n){return{getPing:function(){return n.getCdfBase()+"/ping";
}}});