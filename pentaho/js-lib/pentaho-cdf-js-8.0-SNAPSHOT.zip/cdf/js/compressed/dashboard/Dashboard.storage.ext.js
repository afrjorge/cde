define(["./Dashboard.ext"],function(e){return{getStorage:function(t){return e.getCdfBase()+"/storage/"+t;
}}});