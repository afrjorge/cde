define(["pentaho/type/Context"],function(n){var t;return{getInstance:function(){return t||(t=new n({
application:"pentaho-cdf"})),t}}});