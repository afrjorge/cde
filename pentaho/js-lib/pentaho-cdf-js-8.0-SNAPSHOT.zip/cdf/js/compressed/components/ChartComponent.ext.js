define(["../dashboard/Dashboard.ext"],function(e){return{getCccScriptPath:function(r){
return e.getFilePathFromUrl().replace(/[^\/]+$/,"")+r+".js"}}});