define(["./BaseComponent","../OlapUtils"],function(e,n){return e.extend({visible:!1,
update:function(){n.updateMdxQueryGroup(this)}})});