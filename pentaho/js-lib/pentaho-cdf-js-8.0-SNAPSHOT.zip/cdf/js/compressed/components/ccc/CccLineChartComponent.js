define(["./BaseCccComponent","../../lib/CCC/pvc"],function(e,n){return e.extend({
cccType:n.LineChart})});