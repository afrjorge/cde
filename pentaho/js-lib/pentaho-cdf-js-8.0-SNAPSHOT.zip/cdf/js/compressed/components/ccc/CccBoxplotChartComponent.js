define(["./BaseCccComponent","../../lib/CCC/pvc"],function(e,c){return e.extend({
cccType:c.BoxplotChart})});