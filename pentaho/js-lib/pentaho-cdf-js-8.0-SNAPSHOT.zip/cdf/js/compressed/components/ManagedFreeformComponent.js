define(["./BaseComponent"],function(n){return n.extend({update:function(){this.customfunction(this.parameters||[]);
}})});