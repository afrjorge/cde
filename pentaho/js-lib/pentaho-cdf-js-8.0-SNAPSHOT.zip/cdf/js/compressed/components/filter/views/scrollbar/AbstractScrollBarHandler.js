define(["../../../../lib/Base"],function(n){return n.extend({scrollToPosition:function(n){}
})});