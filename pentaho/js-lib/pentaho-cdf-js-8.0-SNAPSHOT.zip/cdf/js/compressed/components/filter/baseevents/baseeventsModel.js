define(["amd!../../../lib/backbone","../../../lib/BaseEvents"],function(e,n){return n.convertClass(e.Model);
});