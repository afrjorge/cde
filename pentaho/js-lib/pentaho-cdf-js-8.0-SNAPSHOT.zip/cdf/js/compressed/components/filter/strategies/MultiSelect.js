define(["amd!../../../lib/underscore","./AbstractSelect"],function(e,t){return t.extend({
ID:"BaseFilter.SelectionStrategies.MultiSelect",setSelection:function(e,t){return t.setAndUpdateSelection(e),
e}})});