define(["./Root","./Group","./Item"],function(o,t,e){return{Root:o,Group:t,Item:e
}});