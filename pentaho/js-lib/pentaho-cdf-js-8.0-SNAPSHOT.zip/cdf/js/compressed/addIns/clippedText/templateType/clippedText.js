define(["../../../AddIn","../clippedTextBase","../../../Dashboard","../../../lib/jquery","css!./clippedText"],function(e,t,n,d){
var i=new e(d.extend(!0,{},t,{defaults:{useTipsy:!0},init:function(){}}));return n.registerGlobalAddIn("Template","templateType",i),
i});