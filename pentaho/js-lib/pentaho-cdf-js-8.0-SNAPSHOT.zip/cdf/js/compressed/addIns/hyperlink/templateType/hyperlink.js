define(["../../../AddIn","../hyperlinkBase","../../../Dashboard","../../../lib/jquery"],function(e,n,r,l){
var a=new e(l.extend(!0,{},n,{defaults:{urlReference:1,labelReference:0}}));return r.registerGlobalAddIn("Template","templateType",a),
a});