define(["../../../AddIn","../templateBase","../../../Dashboard"],function(e,a,t){
var n=new e(a);return t.registerGlobalAddIn("Template","templateType",n),n});